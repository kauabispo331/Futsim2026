/* =====================================================
   Craque Manager — lógica do jogo
   Tudo roda no navegador. Equipes ficam salvas em localStorage.
   ===================================================== */

const STORAGE_KEY = "craque-manager:teams";

const POSITIONS = ["GOL", "ZAG", "LAT", "VOL", "MEI", "ATA"];

const DEFAULT_TEAMS = [
  {
    id: "leoes",
    name: "Leões do Vale",
    abbr: "LEV",
    colorPrimary: "#2f7a3d",
    colorSecondary: "#e8c547",
    players: [
      { name: "Bira", position: "GOL", rating: 74 },
      { name: "Nunes", position: "ZAG", rating: 71 },
      { name: "Cacau", position: "ZAG", rating: 73 },
      { name: "Ravel", position: "LAT", rating: 68 },
      { name: "Dodô", position: "LAT", rating: 67 },
      { name: "Tico", position: "VOL", rating: 72 },
      { name: "Marinho", position: "MEI", rating: 75 },
      { name: "Val", position: "MEI", rating: 70 },
      { name: "Preto", position: "ATA", rating: 78 },
      { name: "Igor", position: "ATA", rating: 76 },
      { name: "Samuka", position: "ATA", rating: 73 }
    ]
  },
  {
    id: "aguias",
    name: "Águias United",
    abbr: "AGU",
    colorPrimary: "#1f4fb5",
    colorSecondary: "#f3efe1",
    players: [
      { name: "Wender", position: "GOL", rating: 77 },
      { name: "Kaká Jr", position: "ZAG", rating: 75 },
      { name: "Serra", position: "ZAG", rating: 70 },
      { name: "Bruno T", position: "LAT", rating: 72 },
      { name: "Léo Reis", position: "LAT", rating: 69 },
      { name: "Pati", position: "VOL", rating: 74 },
      { name: "Gordinho", position: "MEI", rating: 71 },
      { name: "Suel", position: "MEI", rating: 73 },
      { name: "Rafinha", position: "ATA", rating: 79 },
      { name: "Cebola", position: "ATA", rating: 72 },
      { name: "Tande", position: "ATA", rating: 75 }
    ]
  },
  {
    id: "tubaroes",
    name: "Tubarões da Vila",
    abbr: "TUB",
    colorPrimary: "#111318",
    colorSecondary: "#e2543a",
    players: [
      { name: "Piu", position: "GOL", rating: 69 },
      { name: "Alemão", position: "ZAG", rating: 68 },
      { name: "Gonza", position: "ZAG", rating: 72 },
      { name: "Michel", position: "LAT", rating: 66 },
      { name: "Toinho", position: "LAT", rating: 65 },
      { name: "Deda", position: "VOL", rating: 70 },
      { name: "Xará", position: "MEI", rating: 68 },
      { name: "Junim", position: "MEI", rating: 71 },
      { name: "Formiga", position: "ATA", rating: 74 },
      { name: "Bolt", position: "ATA", rating: 77 },
      { name: "Vini Z", position: "ATA", rating: 70 }
    ]
  },
  {
    id: "falcoes",
    name: "Falcões FC",
    abbr: "FAL",
    colorPrimary: "#6c3fb5",
    colorSecondary: "#f3efe1",
    players: [
      { name: "Renan", position: "GOL", rating: 72 },
      { name: "Duda", position: "ZAG", rating: 74 },
      { name: "Zeca", position: "ZAG", rating: 69 },
      { name: "Ítalo", position: "LAT", rating: 70 },
      { name: "Robertinho", position: "LAT", rating: 68 },
      { name: "Cauê", position: "VOL", rating: 73 },
      { name: "Pipoca", position: "MEI", rating: 76 },
      { name: "Wagninho", position: "MEI", rating: 72 },
      { name: "Zóio", position: "ATA", rating: 75 },
      { name: "Bala", position: "ATA", rating: 78 },
      { name: "Marley", position: "ATA", rating: 71 }
    ]
  }
];

/* ---------------- estado + persistência ---------------- */

let teams = loadTeams();
let editingTeamId = teams[0]?.id ?? null;

function loadTeams(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return structuredClone(DEFAULT_TEAMS);
    const parsed = JSON.parse(raw);
    if(!Array.isArray(parsed) || parsed.length === 0) return structuredClone(DEFAULT_TEAMS);
    return parsed;
  }catch(err){
    console.warn("Não foi possível ler as equipes salvas, usando padrão.", err);
    return structuredClone(DEFAULT_TEAMS);
  }
}

function saveTeams(){
  try{
    localStorage.setItem(STORAGE_KEY, JSON.stringify(teams));
    return true;
  }catch(err){
    console.error("Falha ao salvar equipes:", err);
    return false;
  }
}

function findTeam(id){ return teams.find(t => t.id === id) || null; }

function teamStrength(team){
  if(!team.players.length) return 50;
  const sum = team.players.reduce((acc, p) => acc + Number(p.rating || 0), 0);
  return sum / team.players.length;
}

function slugify(str){
  return str
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || "equipe";
}

function uniqueId(base){
  let id = base, n = 1;
  while(teams.some(t => t.id === id)){ id = `${base}-${n++}`; }
  return id;
}

/* ===================================================================
   ABAS
   =================================================================== */

document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => {
      b.classList.remove("is-active");
      b.setAttribute("aria-selected", "false");
    });
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("is-active"));

    btn.classList.add("is-active");
    btn.setAttribute("aria-selected", "true");
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add("is-active");
  });
});

/* ===================================================================
   MODO AMISTOSO
   =================================================================== */

const selectMandante = document.getElementById("select-mandante");
const selectVisitante = document.getElementById("select-visitante");
const chipMandante = document.getElementById("chip-mandante");
const chipVisitante = document.getElementById("chip-visitante");
const btnSimular = document.getElementById("btn-simular");
const btnSortear = document.getElementById("btn-sortear");
const scoreboardEl = document.getElementById("scoreboard");
const matchBodyEl = document.getElementById("match-body");
const matchLogEl = document.getElementById("match-log");
const matchSummaryEl = document.getElementById("match-summary");
const emptyHint = document.getElementById("empty-hint");
const matchClock = document.getElementById("match-clock");

function renderFriendlySelects(){
  const prevHome = selectMandante.value;
  const prevAway = selectVisitante.value;

  [selectMandante, selectVisitante].forEach(sel => { sel.innerHTML = ""; });

  teams.forEach(team => {
    const optA = document.createElement("option");
    optA.value = team.id;
    optA.textContent = team.name;
    selectMandante.appendChild(optA);

    const optB = optA.cloneNode(true);
    selectVisitante.appendChild(optB);
  });

  if(teams.some(t => t.id === prevHome)) selectMandante.value = prevHome;
  if(teams.some(t => t.id === prevAway)) selectVisitante.value = prevAway;
  if(selectMandante.value === selectVisitante.value && teams.length > 1){
    selectVisitante.selectedIndex = selectVisitante.selectedIndex === 0 ? 1 : 0;
  }

  updateChips();
}

function updateChips(){
  const home = findTeam(selectMandante.value);
  const away = findTeam(selectVisitante.value);
  chipMandante.textContent = home ? `${home.abbr} · força média ${teamStrength(home).toFixed(0)}` : "";
  chipMandante.style.borderLeftColor = home?.colorPrimary || "var(--turf)";
  chipVisitante.textContent = away ? `${away.abbr} · força média ${teamStrength(away).toFixed(0)}` : "";
  chipVisitante.style.borderLeftColor = away?.colorPrimary || "var(--turf)";

  const same = home && away && home.id === away.id;
  btnSimular.disabled = !home || !away || same || teams.length < 2;
  btnSimular.title = same ? "Escolha dois times diferentes" : "";
}

selectMandante.addEventListener("change", updateChips);
selectVisitante.addEventListener("change", updateChips);

btnSortear.addEventListener("click", () => {
  if(teams.length < 2) return;
  const shuffled = [...teams].sort(() => Math.random() - 0.5);
  selectMandante.value = shuffled[0].id;
  selectVisitante.value = shuffled[1].id;
  updateChips();
});

/* ---- motor de simulação ---- */

// amostra de Poisson (algoritmo de Knuth) — usado para número de gols
function poissonSample(lambda){
  const L = Math.exp(-lambda);
  let k = 0, p = 1;
  do{
    k++;
    p *= Math.random();
  }while(p > L);
  return k - 1;
}

function pickWeighted(players, weightFn){
  const weights = players.map(weightFn);
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for(let i = 0; i < players.length; i++){
    r -= weights[i];
    if(r <= 0) return players[i];
  }
  return players[players.length - 1];
}

function attackWeight(player){
  const positionBoost = { ATA: 3, MEI: 2, VOL: 1.3, LAT: 1, ZAG: 0.4, GOL: 0.05 }[player.position] ?? 1;
  return Math.max(1, Number(player.rating || 50)) * positionBoost;
}

const CARD_NAMES = ["falta dura", "reclamação", "atraso tático", "entrada forte"];
const CHANCE_NAMES = ["cabeceio para fora", "chute na trave", "defesa em dois tempos", "bola na rede pelo lado de fora"];

function simulateMatch(home, away){
  const homeAdv = 3;
  const strengthHome = teamStrength(home) + homeAdv;
  const strengthAway = teamStrength(away);

  const expectedHome = Math.max(0.35, 1.15 + (strengthHome - strengthAway) / 14);
  const expectedAway = Math.max(0.25, 1.0 + (strengthAway - strengthHome) / 14);

  const goalsHome = Math.min(8, poissonSample(expectedHome));
  const goalsAway = Math.min(8, poissonSample(expectedAway));

  const events = [];
  const usedMinutes = new Set();

  function freeMinute(){
    let m;
    do{ m = 1 + Math.floor(Math.random() * 90); }while(usedMinutes.has(m));
    usedMinutes.add(m);
    return m;
  }

  for(let i = 0; i < goalsHome; i++){
    const scorer = pickWeighted(home.players, attackWeight);
    events.push({ minute: freeMinute(), type: "goal", team: "home", text: `GOL do ${home.name}! ${scorer.name} balança as redes.` });
  }
  for(let i = 0; i < goalsAway; i++){
    const scorer = pickWeighted(away.players, attackWeight);
    events.push({ minute: freeMinute(), type: "goal", team: "away", text: `GOL do ${away.name}! ${scorer.name} balança as redes.` });
  }

  // eventos de cor: chances perdidas e cartões
  const extraCount = 3 + Math.floor(Math.random() * 4);
  for(let i = 0; i < extraCount; i++){
    const isCard = Math.random() < 0.4;
    const isHomeSide = Math.random() < 0.5;
    const team = isHomeSide ? home : away;
    if(isCard){
      const player = team.players[Math.floor(Math.random() * team.players.length)];
      const reason = CARD_NAMES[Math.floor(Math.random() * CARD_NAMES.length)];
      events.push({ minute: freeMinute(), type: "card-yellow", team: isHomeSide ? "home" : "away", text: `Cartão amarelo para ${player.name} (${team.abbr}) — ${reason}.` });
    }else{
      const player = pickWeighted(team.players, attackWeight);
      const chance = CHANCE_NAMES[Math.floor(Math.random() * CHANCE_NAMES.length)];
      events.push({ minute: freeMinute(), type: "chance", team: isHomeSide ? "home" : "away", text: `${player.name} (${team.abbr}) quase marca: ${chance}.` });
    }
  }

  events.push({ minute: 90, type: "end", team: null, text: `Apito final em ${home.name} ${goalsHome} × ${goalsAway} ${away.name}.` });
  events.sort((a, b) => a.minute - b.minute);

  // artilheiro / MVP simples: melhor jogador do time vencedor (ou geral em empate)
  let mvpTeam = home, mvpLabel = "Melhor em campo";
  if(goalsAway > goalsHome) mvpTeam = away;
  const mvp = [...mvpTeam.players].sort((a, b) => b.rating - a.rating)[0];

  return {
    home, away, goalsHome, goalsAway, events,
    mvp, mvpTeam,
    result: goalsHome === goalsAway ? "empate" : (goalsHome > goalsAway ? "home" : "away")
  };
}

let simulationTimer = null;

btnSimular.addEventListener("click", () => {
  const home = findTeam(selectMandante.value);
  const away = findTeam(selectVisitante.value);
  if(!home || !away || home.id === away.id) return;

  clearInterval(simulationTimer);
  matchLogEl.innerHTML = "";
  matchSummaryEl.hidden = true;
  emptyHint.hidden = true;
  scoreboardEl.hidden = false;
  matchBodyEl.hidden = false;
  btnSimular.disabled = true;
  btnSortear.disabled = true;

  document.getElementById("score-home-team").textContent = home.abbr;
  document.getElementById("score-away-team").textContent = away.abbr;
  document.getElementById("score-home").textContent = "0";
  document.getElementById("score-away").textContent = "0";
  matchClock.textContent = "0'";

  const match = simulateMatch(home, away);
  let goalsHomeSoFar = 0, goalsAwaySoFar = 0;
  let index = 0;

  simulationTimer = setInterval(() => {
    if(index >= match.events.length){
      clearInterval(simulationTimer);
      renderMatchSummary(match);
      btnSimular.disabled = false;
      btnSortear.disabled = false;
      return;
    }
    const ev = match.events[index++];
    matchClock.textContent = `${ev.minute}'`;

    if(ev.type === "goal"){
      if(ev.team === "home"){ goalsHomeSoFar++; document.getElementById("score-home").textContent = goalsHomeSoFar; }
      else{ goalsAwaySoFar++; document.getElementById("score-away").textContent = goalsAwaySoFar; }
    }

    const li = document.createElement("li");
    if(ev.type === "goal") li.classList.add("log-goal");
    if(ev.type === "card-yellow") li.classList.add("log-card-yellow");
    li.innerHTML = `<span class="log-minute">${ev.minute}'</span><span>${escapeHtml(ev.text)}</span>`;
    matchLogEl.appendChild(li);
    matchLogEl.scrollTop = matchLogEl.scrollHeight;
  }, 180);
});

function renderMatchSummary(match){
  matchSummaryEl.hidden = false;
  const resultLabel = match.result === "empate"
    ? "Empate"
    : `Vitória do ${match.result === "home" ? match.home.name : match.away.name}`;

  matchSummaryEl.innerHTML = `
    <h3>Resumo</h3>
    <dl>
      <dt>Resultado</dt><dd>${escapeHtml(resultLabel)}</dd>
      <dt>Placar</dt><dd>${match.home.abbr} ${match.goalsHome} – ${match.goalsAway} ${match.away.abbr}</dd>
      <dt>Destaque da partida</dt><dd>${escapeHtml(match.mvp.name)} (${escapeHtml(match.mvpTeam.abbr)})</dd>
      <dt>Força média</dt><dd>${teamStrength(match.home).toFixed(0)} × ${teamStrength(match.away).toFixed(0)}</dd>
    </dl>
  `;
}

function escapeHtml(str){
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

/* ===================================================================
   MODO EDITAR
   =================================================================== */

const selectEditTeam = document.getElementById("select-edit-team");
const btnNovaEquipe = document.getElementById("btn-nova-equipe");
const btnExcluirEquipe = document.getElementById("btn-excluir-equipe");
const btnRestaurar = document.getElementById("btn-restaurar");
const teamForm = document.getElementById("team-form");
const inputName = document.getElementById("input-team-name");
const inputAbbr = document.getElementById("input-team-abbr");
const inputColorPrimary = document.getElementById("input-color-primary");
const inputColorSecondary = document.getElementById("input-color-secondary");
const teamPreview = document.getElementById("team-preview");
const rosterBody = document.getElementById("roster-body");
const rosterAvgValue = document.getElementById("roster-avg-value");
const btnAddPlayer = document.getElementById("btn-add-player");
const btnSalvar = document.getElementById("btn-salvar");
const saveStatus = document.getElementById("save-status");

function renderEditSelect(){
  const prev = selectEditTeam.value;
  selectEditTeam.innerHTML = "";
  teams.forEach(team => {
    const opt = document.createElement("option");
    opt.value = team.id;
    opt.textContent = team.name;
    selectEditTeam.appendChild(opt);
  });
  if(teams.some(t => t.id === prev)){
    selectEditTeam.value = prev;
  }else if(teams.length){
    selectEditTeam.value = teams[0].id;
  }
  editingTeamId = selectEditTeam.value || null;
  btnExcluirEquipe.disabled = teams.length <= 1;
  loadTeamIntoForm();
}

function loadTeamIntoForm(){
  const team = findTeam(editingTeamId);
  if(!team){
    teamForm.hidden = true;
    rosterBody.innerHTML = "";
    rosterAvgValue.textContent = "–";
    return;
  }
  teamForm.hidden = false;
  inputName.value = team.name;
  inputAbbr.value = team.abbr;
  inputColorPrimary.value = team.colorPrimary;
  inputColorSecondary.value = team.colorSecondary;
  updatePreview();
  renderRoster(team);
  saveStatus.textContent = "";
}

function updatePreview(){
  teamPreview.textContent = `${inputAbbr.value.toUpperCase() || "SIG"} — ${inputName.value || "Nome da equipe"}`;
  teamPreview.style.background = inputColorPrimary.value;
  teamPreview.style.color = inputColorSecondary.value;
}

[inputName, inputAbbr, inputColorPrimary, inputColorSecondary].forEach(el => {
  el.addEventListener("input", updatePreview);
});

function renderRoster(team){
  rosterBody.innerHTML = "";
  team.players.forEach((player, idx) => {
    rosterBody.appendChild(buildPlayerRow(player, idx));
  });
  updateRosterAvg(team);
}

function buildPlayerRow(player, idx){
  const tr = document.createElement("tr");
  tr.dataset.index = idx;

  const tdName = document.createElement("td");
  tdName.className = "col-name";
  const nameInput = document.createElement("input");
  nameInput.type = "text";
  nameInput.maxLength = 20;
  nameInput.value = player.name;
  nameInput.addEventListener("input", () => { player.name = nameInput.value; });
  tdName.appendChild(nameInput);

  const tdPos = document.createElement("td");
  tdPos.className = "col-pos";
  const posSelect = document.createElement("select");
  POSITIONS.forEach(pos => {
    const opt = document.createElement("option");
    opt.value = pos;
    opt.textContent = pos;
    if(pos === player.position) opt.selected = true;
    posSelect.appendChild(opt);
  });
  posSelect.addEventListener("change", () => { player.position = posSelect.value; });
  tdPos.appendChild(posSelect);

  const tdRating = document.createElement("td");
  tdRating.className = "col-rating";
  const ratingInput = document.createElement("input");
  ratingInput.type = "number";
  ratingInput.min = "30";
  ratingInput.max = "99";
  ratingInput.value = player.rating;
  ratingInput.addEventListener("input", () => {
    let v = Number(ratingInput.value);
    if(Number.isNaN(v)) v = 50;
    v = Math.min(99, Math.max(30, v));
    player.rating = v;
    updateRosterAvg(findTeam(editingTeamId));
  });
  tdRating.appendChild(ratingInput);

  const tdRemove = document.createElement("td");
  tdRemove.className = "col-remove";
  const removeBtn = document.createElement("button");
  removeBtn.type = "button";
  removeBtn.className = "btn-remove-player";
  removeBtn.title = "Remover jogador";
  removeBtn.textContent = "✕";
  removeBtn.addEventListener("click", () => {
    const team = findTeam(editingTeamId);
    if(team.players.length <= 7){
      saveStatus.textContent = "Uma equipe precisa de pelo menos 7 jogadores.";
      saveStatus.style.color = "var(--scarlet)";
      return;
    }
    team.players.splice(idx, 1);
    renderRoster(team);
  });
  tdRemove.appendChild(removeBtn);

  tr.append(tdName, tdPos, tdRating, tdRemove);
  return tr;
}

function updateRosterAvg(team){
  if(!team || !team.players.length){ rosterAvgValue.textContent = "–"; return; }
  rosterAvgValue.textContent = teamStrength(team).toFixed(1);
}

btnAddPlayer.addEventListener("click", () => {
  const team = findTeam(editingTeamId);
  if(!team) return;
  if(team.players.length >= 20){
    saveStatus.textContent = "Elenco no limite de 20 jogadores.";
    saveStatus.style.color = "var(--scarlet)";
    return;
  }
  team.players.push({ name: "Novo jogador", position: "MEI", rating: 65 });
  renderRoster(team);
});

selectEditTeam.addEventListener("change", () => {
  editingTeamId = selectEditTeam.value;
  loadTeamIntoForm();
});

btnNovaEquipe.addEventListener("click", () => {
  const name = "Nova Equipe";
  const id = uniqueId(slugify(name));
  const newTeam = {
    id, name, abbr: "NEW",
    colorPrimary: "#2f7a3d", colorSecondary: "#f3efe1",
    players: [
      { name: "Jogador 1", position: "GOL", rating: 65 },
      { name: "Jogador 2", position: "ZAG", rating: 65 },
      { name: "Jogador 3", position: "ZAG", rating: 65 },
      { name: "Jogador 4", position: "LAT", rating: 65 },
      { name: "Jogador 5", position: "LAT", rating: 65 },
      { name: "Jogador 6", position: "VOL", rating: 65 },
      { name: "Jogador 7", position: "MEI", rating: 65 },
      { name: "Jogador 8", position: "MEI", rating: 65 },
      { name: "Jogador 9", position: "ATA", rating: 65 },
      { name: "Jogador 10", position: "ATA", rating: 65 },
      { name: "Jogador 11", position: "ATA", rating: 65 }
    ]
  };
  teams.push(newTeam);
  saveTeams();
  editingTeamId = id;
  renderEditSelect();
  renderFriendlySelects();
  inputName.focus();
  inputName.select();
});

btnExcluirEquipe.addEventListener("click", () => {
  if(teams.length <= 1) return;
  const team = findTeam(editingTeamId);
  if(!team) return;
  if(!confirm(`Excluir a equipe "${team.name}"? Essa ação não pode ser desfeita.`)) return;
  teams = teams.filter(t => t.id !== editingTeamId);
  saveTeams();
  renderEditSelect();
  renderFriendlySelects();
});

btnRestaurar.addEventListener("click", () => {
  const defaultTeam = DEFAULT_TEAMS.find(t => t.id === editingTeamId);
  if(!defaultTeam){
    saveStatus.textContent = "Essa equipe não tem versão padrão para restaurar.";
    saveStatus.style.color = "var(--scarlet)";
    return;
  }
  if(!confirm("Restaurar os dados originais desta equipe? As alterações não salvas serão perdidas.")) return;
  const idx = teams.findIndex(t => t.id === editingTeamId);
  teams[idx] = structuredClone(defaultTeam);
  loadTeamIntoForm();
});

btnSalvar.addEventListener("click", () => {
  const team = findTeam(editingTeamId);
  if(!team) return;

  const name = inputName.value.trim();
  const abbr = inputAbbr.value.trim().toUpperCase();
  if(!name || !abbr){
    saveStatus.textContent = "Preencha nome e sigla antes de salvar.";
    saveStatus.style.color = "var(--scarlet)";
    return;
  }
  if(team.players.some(p => !p.name.trim())){
    saveStatus.textContent = "Todo jogador precisa de um nome.";
    saveStatus.style.color = "var(--scarlet)";
    return;
  }

  team.name = name;
  team.abbr = abbr;
  team.colorPrimary = inputColorPrimary.value;
  team.colorSecondary = inputColorSecondary.value;

  const ok = saveTeams();
  saveStatus.textContent = ok ? "Equipe salva ✓" : "Não foi possível salvar (armazenamento indisponível).";
  saveStatus.style.color = ok ? "var(--turf)" : "var(--scarlet)";

  renderEditSelect();
  selectEditTeam.value = team.id;
  editingTeamId = team.id;
  renderFriendlySelects();
});

/* ===================================================================
   INICIALIZAÇÃO
   =================================================================== */

renderFriendlySelects();
renderEditSelect();
