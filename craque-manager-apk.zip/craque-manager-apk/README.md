# ⚽ Craque Manager — versão Android (APK)

Este repositório empacota o jogo [Craque Manager](../craque-manager) (a pasta `www/`) como um app Android
usando [Capacitor](https://capacitorjs.com/). O APK é gerado **automaticamente pelo GitHub Actions** —
você não precisa instalar Android Studio na sua máquina.

## Estrutura

```
www/                          → o jogo em si (HTML/CSS/JS), igual ao da versão web
capacitor.config.json         → configuração do Capacitor (nome do app, pasta web)
package.json                  → dependências do Capacitor
.github/workflows/build-apk.yml → workflow que gera o APK a cada push
```

## Como gerar o APK

1. Crie um repositório novo no GitHub (ex: `craque-manager-apk`) e suba todos os arquivos desta pasta,
   mantendo a estrutura (incluindo a pasta `.github/workflows`).

   ```bash
   cd craque-manager-apk
   git init
   git add .
   git commit -m "App Android do Craque Manager"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/craque-manager-apk.git
   git push -u origin main
   ```

2. Assim que o push terminar, vá na aba **Actions** do repositório no GitHub. Vai aparecer um workflow
   chamado **Build APK** rodando (leva alguns minutos — ele baixa o Android SDK e compila).

3. Quando o workflow terminar com um ✅ verde, clique nele e desça até **Artifacts**. Vai ter um arquivo
   `craque-manager-debug-apk` — baixe e descompacte: dentro está o `app-debug.apk`.

4. Transfira o `app-debug.apk` para o celular (Android) e instale. Talvez seja preciso permitir
   "instalar de fontes desconhecidas" nas configurações do aparelho.

Se quiser rodar o build manualmente sem esperar um push, use a aba **Actions → Build APK → Run workflow**
(o gatilho `workflow_dispatch` já está configurado).

## Personalizando o app

- **Nome do app e ID**: edite `appName` e `appId` em `capacitor.config.json` antes do primeiro build.
- **Ícone e splash screen**: depois de gerar o projeto Android uma vez localmente
  (`npm install && npx cap add android`), você pode usar
  [`@capacitor/assets`](https://github.com/ionic-team/capacitor-assets) para gerar ícones automaticamente,
  ou editar diretamente `android/app/src/main/res`.
- **Atualizar o jogo**: qualquer alteração na pasta `www/` e um novo push já gera um APK atualizado.

## Gerando um APK assinado para a Play Store (opcional)

O workflow atual gera um **APK de debug**, ótimo para testar no seu celular. Para publicar na Play Store
você precisaria gerar uma keystore de assinatura e trocar `assembleDebug` por `assembleRelease` no
workflow, além de configurar os segredos de assinatura no GitHub (Settings → Secrets). Se quiser, posso
te ajudar a montar essa parte depois.
